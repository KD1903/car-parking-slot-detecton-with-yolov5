
parking - v1 2022-06-04 10:43am
==============================

This dataset was exported via roboflow.ai on June 4, 2022 at 5:14 AM GMT

It includes 401 images.
Car-parkingslot are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


